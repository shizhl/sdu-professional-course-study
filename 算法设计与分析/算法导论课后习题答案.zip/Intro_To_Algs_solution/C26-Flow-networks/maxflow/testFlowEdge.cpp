/*************************************************************************
	> File Name: testFlowEdge.cpp
	> Author: Louis1992
	> Mail: zhenchaogan@gmail.com
	> Blog: http://gzc.github.io
	> Created Time: Fri Nov 13 08:27:56 2015
 ************************************************************************/
#include<iostream>
#include "FlowEdge.cpp"
using namespace std;

int main() {
    FlowEdge e(12, 23, 3.14);
    cout << e;
    return 1;
}