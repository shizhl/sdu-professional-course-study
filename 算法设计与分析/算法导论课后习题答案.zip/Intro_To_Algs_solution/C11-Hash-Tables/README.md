UNSOLVED

[11.1.4](./11.1.md#exercises-111-4)

[11.3.5](./11.3.md#exercises-113-5)
[11.3.6](./11.3.md#exercises-113-6)

[11.5.1](./11.5.md#exercises-115-1)
